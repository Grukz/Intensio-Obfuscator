# -*- coding: utf-8 -*-

oYrPWWnKeCOBEhqzLLJcdrAYWQiowkjt = 'WgehkQVyDoqnaVWydctRelWHHDboBSJa'
xXMxQumTDjKbmyEACayqjeuVQBaMKBGW = 'ZbGkfpWLkYhNqyBDeThNuNJzcUJIBsjE'
uZgUyJoeMdAMbUZsDTfTmVahQVHTKbLe = 'SXklqoSKBwYrrvvpyjUZQryHOTiRhCPd'
MoFHgWTzDgQVLAOKriBncLmToyjiTlbS = 'mTxofvyvcANRcxRDkLFCvUJcepxDpHHG'
rUPTlNvXrSFXxrrYiiRtBBtDIuNUELyO = 'nkwToZGBetdzwDqPZqWcLnPwJxWmPrlr'
if oYrPWWnKeCOBEhqzLLJcdrAYWQiowkjt in xXMxQumTDjKbmyEACayqjeuVQBaMKBGW:
    oYrPWWnKeCOBEhqzLLJcdrAYWQiowkjt = rUPTlNvXrSFXxrrYiiRtBBtDIuNUELyO
    if xXMxQumTDjKbmyEACayqjeuVQBaMKBGW in uZgUyJoeMdAMbUZsDTfTmVahQVHTKbLe:
        xXMxQumTDjKbmyEACayqjeuVQBaMKBGW = MoFHgWTzDgQVLAOKriBncLmToyjiTlbS
elif xXMxQumTDjKbmyEACayqjeuVQBaMKBGW in oYrPWWnKeCOBEhqzLLJcdrAYWQiowkjt:
    uZgUyJoeMdAMbUZsDTfTmVahQVHTKbLe = xXMxQumTDjKbmyEACayqjeuVQBaMKBGW
    if uZgUyJoeMdAMbUZsDTfTmVahQVHTKbLe in xXMxQumTDjKbmyEACayqjeuVQBaMKBGW:
        xXMxQumTDjKbmyEACayqjeuVQBaMKBGW = rUPTlNvXrSFXxrrYiiRtBBtDIuNUELyO
def peNsdNqpqIpCSZKCkGdTGcBYeqonlkiY(bytes):
    ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI = 0

    mlznXXUlhXkqUkuOnWartQgqbQFkKbpW = 'CWjiDWvUzzfjJzctVpWACsBBqkePscNl'
    ZiZDmOjQTxfEAvmUkDJuAESamcYZREnS = 'hAUXIwrIaLTVAzqgrSBixvouIzqDdykP'
    if mlznXXUlhXkqUkuOnWartQgqbQFkKbpW != ZiZDmOjQTxfEAvmUkDJuAESamcYZREnS:
        mlznXXUlhXkqUkuOnWartQgqbQFkKbpW = 'hAUXIwrIaLTVAzqgrSBixvouIzqDdykP'
        ZiZDmOjQTxfEAvmUkDJuAESamcYZREnS = mlznXXUlhXkqUkuOnWartQgqbQFkKbpW
        mlznXXUlhXkqUkuOnWartQgqbQFkKbpW = 'CWjiDWvUzzfjJzctVpWACsBBqkePscNl'
    while bytes:

        vqUXlSahUwfGDaWFVUuzCmcQPibxyShw = 'PEuoJCENUCsAtVrBoMKmMxBpahwMNdJQ'
        nRgjccSTNaEbpWWwFlxUfjYaptYCuKqp = 'WtMDsikzNnofhBNuqSdyOpmBoZZcWgnA'
        BNiycOtuUMnnKttmpLBcJEqzqXEaGESB = 'ftOmwRRlAoOVAolScFrnjRoJccKMMLvJ'
        if vqUXlSahUwfGDaWFVUuzCmcQPibxyShw == nRgjccSTNaEbpWWwFlxUfjYaptYCuKqp:
            BNiycOtuUMnnKttmpLBcJEqzqXEaGESB = 'ftOmwRRlAoOVAolScFrnjRoJccKMMLvJ'
            BNiycOtuUMnnKttmpLBcJEqzqXEaGESB = vqUXlSahUwfGDaWFVUuzCmcQPibxyShw
        else:
            BNiycOtuUMnnKttmpLBcJEqzqXEaGESB = 'ftOmwRRlAoOVAolScFrnjRoJccKMMLvJ'
            BNiycOtuUMnnKttmpLBcJEqzqXEaGESB = 'PEuoJCENUCsAtVrBoMKmMxBpahwMNdJQ'
        ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI = ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI << 8

        cMKvEWRReKJFxGpAQWwvmWEMnkdBwrhl = 'IzpGCRABUViLgnGcIjRgkKAEXYytwkuz'
        smmVqSOABGApWCCkArXjARtQTxfBLYiJ = 'ugAhnrtNRVLksoChYSOXHaexZwxsdcFJ'
        nceUhQgBqJwsUMfVEEqORdDfSZNBeVzB = 'cXGGsgTPHnfAJFUfoEYkhvxtdAFFTdZi'
        lXEkTUwhXpWUnQCSbXQpbBcpgibbQHqQ = 'IWRnFPpbeRXUuTJtbTbNfUACqUyzsqsa'
        dKeBlKQUcXimaynpSUveLhMvaQZVfUBq = 'IvOQSXyjNzLdaatCJBfAfoQPnpLGekGM'
        if cMKvEWRReKJFxGpAQWwvmWEMnkdBwrhl in smmVqSOABGApWCCkArXjARtQTxfBLYiJ:
            cMKvEWRReKJFxGpAQWwvmWEMnkdBwrhl = dKeBlKQUcXimaynpSUveLhMvaQZVfUBq
            if smmVqSOABGApWCCkArXjARtQTxfBLYiJ in nceUhQgBqJwsUMfVEEqORdDfSZNBeVzB:
                smmVqSOABGApWCCkArXjARtQTxfBLYiJ = lXEkTUwhXpWUnQCSbXQpbBcpgibbQHqQ
        elif smmVqSOABGApWCCkArXjARtQTxfBLYiJ in cMKvEWRReKJFxGpAQWwvmWEMnkdBwrhl:
            nceUhQgBqJwsUMfVEEqORdDfSZNBeVzB = smmVqSOABGApWCCkArXjARtQTxfBLYiJ
            if nceUhQgBqJwsUMfVEEqORdDfSZNBeVzB in smmVqSOABGApWCCkArXjARtQTxfBLYiJ:
                smmVqSOABGApWCCkArXjARtQTxfBLYiJ = dKeBlKQUcXimaynpSUveLhMvaQZVfUBq
        ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI += ord(bytes[-1])
        bytes = bytes[:-1]
    return ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI
def TmTSutmFIHdRrAOhGAzlNFhPzNDevirQ(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI):
    crueQJJJuDSxEoVSoUQqvhtKdljWfahH = ''

    try:
        TpsOSJVRwUqnZutPzJvMkCQUbxHTCJef = 'IMkqeBJYQotAaYmBVVfpACSsrrmZYCjH'
        jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz = 'ejRRGclYbhkjKnvVUIhFRopKiariTmrO'
        BXyyoRdozKSjJlSoWfvIrwOlMTKYhsDc = 'jCpkdrJWRdYlnJFyFmOMviyAKQbliIdl'
        loCCqnEXRcZEWWBGsmzTTvbWwOLlBCpt = 'fhZIIJgaZPmZozLJOSAwjurTrguXJvfd'
        cexYPPRmKnzDdAzuKmuuzVlRlJkFOEJM = 'zSQvNMHaNaEIrONeLYarUgrooscLVjgN'
        EUCmtGCDCcpvVTBeaIWeACGAEiKPkXLX = 'jQUjvQoaYLHmQjdHnOLdrpoZihGjtUFO'
        jHfidKNHNnHShZcOkhGHGtZUogcQKUTW = [
                'IMkqeBJYQotAaYmBVVfpACSsrrmZYCjH',
                'jCpkdrJWRdYlnJFyFmOMviyAKQbliIdl',
                'zSQvNMHaNaEIrONeLYarUgrooscLVjgN',
                'vaeBlRRyFPeBSxAJPKMjwqrQCaIJnkht'
        ]
        for TpsOSJVRwUqnZutPzJvMkCQUbxHTCJef in EUCmtGCDCcpvVTBeaIWeACGAEiKPkXLX:
            for jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz in BXyyoRdozKSjJlSoWfvIrwOlMTKYhsDc:
                if loCCqnEXRcZEWWBGsmzTTvbWwOLlBCpt == cexYPPRmKnzDdAzuKmuuzVlRlJkFOEJM:
                    jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz = TpsOSJVRwUqnZutPzJvMkCQUbxHTCJef
                elif cexYPPRmKnzDdAzuKmuuzVlRlJkFOEJM == jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz:
                    jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz = EUCmtGCDCcpvVTBeaIWeACGAEiKPkXLX
                else:
                    cexYPPRmKnzDdAzuKmuuzVlRlJkFOEJM = EUCmtGCDCcpvVTBeaIWeACGAEiKPkXLX
                    for jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz in jHfidKNHNnHShZcOkhGHGtZUogcQKUTW:
                        BXyyoRdozKSjJlSoWfvIrwOlMTKYhsDc = jzQBgLnmPQQmrqAtXWzHUYfKDAJowZoz
    except Exception:
        pass
    while ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI:

        lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA = 'ygzAKVkYoIaAuHoRJHMCUAPUyHqINCGQ'
        HmDQQQFLveyzleUUPjcOwzSXNboHtVCl = 'CMVvlUKQEMIxlRsSXsYgFlGgWyvqGpwh'
        cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj = 'FpyacMPMmGVbduTlrNfHWtSdNeHmKpru'
        vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc = 'MnZrsBqbusjbWehgkHDUpwZoQKvSDhSk'
        if HmDQQQFLveyzleUUPjcOwzSXNboHtVCl == lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA:
            for lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA in HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                if HmDQQQFLveyzleUUPjcOwzSXNboHtVCl == HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                    cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj = 'vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc'
                elif cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj == vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc:
                    vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc = lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA
                else:
                    lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA = HmDQQQFLveyzleUUPjcOwzSXNboHtVCl
        elif cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj == cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj:
            for cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj in HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                if vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc == HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                    cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj = 'vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc'
                elif cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj == vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc:
                    vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc = lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA
                else:
                    lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA = HmDQQQFLveyzleUUPjcOwzSXNboHtVCl
                    for cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj in HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                        if vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc == HmDQQQFLveyzleUUPjcOwzSXNboHtVCl:
                            cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj = 'vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc'
                        elif cWNfHALXqQPRTSNVjtEFiaNxjdcdpanj == vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc:
                            vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc = lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA
                        else:
                            lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA = vSHryeuZtgvzCvsanoBJsbPxdDLSYmvc
        else:
            lDFFxOkmrwWgDjFVgweTAonnZgcgkDxA = HmDQQQFLveyzleUUPjcOwzSXNboHtVCl
        crueQJJJuDSxEoVSoUQqvhtKdljWfahH += chr(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI & 0xff)
        ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI = ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI >> 8

        SYccjLmlsepkHolPPbumumMdvAyLBFKd = 'MBFfTecANcgDdmQiEhhneXceAsRSMdSn'
        DZycBEqvEvWyuFuYCSvqsgOxRFCkxqEW = 'QedGzgiTMvMBLexEBuaCbifMqrQIArSk'
        lyyqYaiabwYSkHWigZWbcivmGUPReVNK = 'VjpRCyRMBQwQcGRXEcVOrdAdqZeWgQbT'
        yTUyDceBUfmFmWtFqYRCHPEkQiLTZoUe = 'sqPDmSbWMBRhuWtwfZZCzwmUcHHyNrPz'
        OrVdybifFrBHyNUYmjNlZDeclyWpLrVM = 'wdXWoiSaXBrmheUGAPvYUWuLcssprFJK'
        FXMlKdGQCmjWrvQOskvlfkTsQbYdtBzx = 'fUFiMxIMLdDcGhZJVrRlmXIrUCjRyRFS'
        if SYccjLmlsepkHolPPbumumMdvAyLBFKd != yTUyDceBUfmFmWtFqYRCHPEkQiLTZoUe:
            DZycBEqvEvWyuFuYCSvqsgOxRFCkxqEW = lyyqYaiabwYSkHWigZWbcivmGUPReVNK
            for FXMlKdGQCmjWrvQOskvlfkTsQbYdtBzx in yTUyDceBUfmFmWtFqYRCHPEkQiLTZoUe:
                if FXMlKdGQCmjWrvQOskvlfkTsQbYdtBzx != lyyqYaiabwYSkHWigZWbcivmGUPReVNK:
                    DZycBEqvEvWyuFuYCSvqsgOxRFCkxqEW = DZycBEqvEvWyuFuYCSvqsgOxRFCkxqEW
                else:
                    OrVdybifFrBHyNUYmjNlZDeclyWpLrVM = SYccjLmlsepkHolPPbumumMdvAyLBFKd
        else:
            lyyqYaiabwYSkHWigZWbcivmGUPReVNK = SYccjLmlsepkHolPPbumumMdvAyLBFKd
            SYccjLmlsepkHolPPbumumMdvAyLBFKd = OrVdybifFrBHyNUYmjNlZDeclyWpLrVM
            if lyyqYaiabwYSkHWigZWbcivmGUPReVNK == SYccjLmlsepkHolPPbumumMdvAyLBFKd:
                for FXMlKdGQCmjWrvQOskvlfkTsQbYdtBzx in SYccjLmlsepkHolPPbumumMdvAyLBFKd:
                    if FXMlKdGQCmjWrvQOskvlfkTsQbYdtBzx == lyyqYaiabwYSkHWigZWbcivmGUPReVNK:
                        lyyqYaiabwYSkHWigZWbcivmGUPReVNK = SYccjLmlsepkHolPPbumumMdvAyLBFKd
                    else:
                        lyyqYaiabwYSkHWigZWbcivmGUPReVNK = OrVdybifFrBHyNUYmjNlZDeclyWpLrVM
    return crueQJJJuDSxEoVSoUQqvhtKdljWfahH
